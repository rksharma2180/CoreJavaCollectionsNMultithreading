package com.simple.testOnOOPS;

import java.util.*;

public class HashSetImplementation {
	
	public static void main(String [] args) {
		
		Set<Student> set = StudentService.addStudents("HashSet");		
		
		for(Student st : set) {
			System.out.println(st.toString());
			System.out.println(st.hashCode());
			System.out.println("Id :- " + st.getId()+"---------");
		}
		
		System.out.println("\n\n"+set);
			
	}
}
