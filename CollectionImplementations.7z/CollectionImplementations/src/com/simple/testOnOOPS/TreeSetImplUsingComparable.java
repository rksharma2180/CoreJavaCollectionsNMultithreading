package com.simple.testOnOOPS;

import java.util.*;

public class TreeSetImplUsingComparable {
	public static void main(String [] args) {
		Set<Student> students = StudentService.addStudents("TreeSet");
		
		for(Student st : students) {
			
			System.out.println(st.toString());
		}
		
		System.out.println("\n\n"+students);
	}
}
