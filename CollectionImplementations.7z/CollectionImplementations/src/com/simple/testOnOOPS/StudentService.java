package com.simple.testOnOOPS;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class StudentService {
	public static Set<Student> addStudents(String implementingCollection){
		
		Set<Student> set = 	new HashSet<Student>();
		Set<Student> treeSet = 	new TreeSet<Student>();
		Set<Student> treeSetComparator  = new TreeSet<Student>(new ComparatorImpl());
		
		Set<Student> treeSetNegativeComparator  = new TreeSet<Student>(new Comparator<Student>() {
			public int compare(Student st1, Student st2) {
				return st2.getId()-st1.getId();
			}
		});
		
		Comparator<Student> treeSetLambdaComparator = (st1, st2) -> st1.getName().compareTo(st2.getName());
		Set<Student> treeset = new TreeSet<Student>(treeSetLambdaComparator);
		
		Student student = null;
		
		Subject subject1 = new Subject(1,"English");
		Subject subject2 = new Subject(2,"Arabic");
		Subject subject3 = new Subject(3,"Marathi");
 		
		List<Subject> subjects = new ArrayList<Subject>();
		subjects.add(subject1);
		subjects.add(subject2);
		subjects.add(subject3);
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Please enter the number of Students in the class :- ");
		int number = sc.nextInt();
		
		
		
		for(int i=0;i<number;i++) {
			student = new Student();
			System.out.println("Please enter the details for Student no. "+ (i+1)+" :-");
			System.out.print("Please enter Student id :- ");
			student.setId(sc.nextInt());
			
			System.out.print("Please enter Student name :- ");
			student.setName(sc.next());
			System.out.println("\n\n");
			
			student.setSubjects(subjects);
			
			set.add(student);
			treeSet.add(student); // Comparable implementing
			treeSetComparator.add(student);  // Comparator implemented Class
			treeSetNegativeComparator.add(student);  //Anonymous inner class implementing Comparator
			treeset.add(student);//Lambda Expression 
		}
		
		sc.close();
		
		if(implementingCollection.equals("HashSet"))
			return set;
		else if(implementingCollection.equals("TreeSetComparator"))
			return treeSetComparator;
		else if(implementingCollection.contentEquals("treeSetNegativeComparator"))
			return treeSetNegativeComparator;
		else if(implementingCollection.equals("treeSetLambdaComparator"));
			return treeset;
	
	}
}
