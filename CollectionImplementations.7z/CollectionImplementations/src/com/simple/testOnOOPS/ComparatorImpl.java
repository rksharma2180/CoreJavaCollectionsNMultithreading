package com.simple.testOnOOPS;

import java.util.*;

public class ComparatorImpl implements Comparator<Student> {
	@Override
	public int compare(Student st1, Student st2) {
		return st1.getId() - st2.getId();
	}
}
