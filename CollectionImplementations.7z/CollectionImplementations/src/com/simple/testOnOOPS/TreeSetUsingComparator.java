package com.simple.testOnOOPS;

import java.util.Set;

public class TreeSetUsingComparator {
	public static void main(String [] args) {
		Set<Student> students = StudentService.addStudents("treeSetLambdaComparator");
		
		
		for(Student st : students) {
			System.out.println(st.toString());
		}
	}
}
