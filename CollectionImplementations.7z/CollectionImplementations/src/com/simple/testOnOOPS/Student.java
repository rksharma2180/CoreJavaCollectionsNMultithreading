package com.simple.testOnOOPS;

import java.util.*;

public class Student implements Comparable {

	private int id;
	private String name;
	private List<Subject> subjects;
		
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	/*
	 * @Override public int compareTo(Object ob2) { // TODO Auto-generated method
	 * stub Student st2 = (Student)ob2; return this.getId() - st2.getId(); }
	 */
	
	@Override
	public int compareTo(final Object ob2) {
		// TODO Auto-generated method stub
		Student st2 = (Student)ob2;
		return this.getName().compareTo(st2.getName());
	}

	public Student(final int id, final String name, final List<Subject> subjects) {
		super();
		this.id = id;
		this.name = name;
		this.subjects = subjects;
	}
	
	@Override
	public int hashCode() {
		return this.getId() + this.getName().charAt(0);
	}
	
	@Override
	public boolean equals(final Object ob) {
		Student st = (Student)ob;
		if(this.getId() == st.getId()) {
			if(this.getName().equals(st.getName())) {
				return true;
			}
		}
		
		return false;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + " Subjects :- " +subjects.toString();
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public List<Subject> getSubjects() {
		return subjects;
	}
	public void setSubjects(List<Subject> subjects) {
		this.subjects = subjects;
	}
	
	
}

