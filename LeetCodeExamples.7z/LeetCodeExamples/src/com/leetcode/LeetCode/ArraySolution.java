/*
 * Given an array nums of n integers where n > 1,  return an array output such that output[i] 
 * is equal to the product of all the elements of nums except nums[i].

Example:

Input:  [1,2,3,4]
Output: [24,12,8,6]
Constraint: It's guaranteed that the product of the elements of any prefix or 
suffix of the array (including the whole array) fits in a 32 bit integer.

Note: Please solve it without division and in O(n).

Follow up:
Could you solve it with constant space complexity? (The output array does not count 
as extra space for the purpose of space complexity analysis.)
 */


package com.leetcode.examples;

public class ArraySolution {
	
	public int[] productExceptSelf(int[] nums) {
		int []output = new int[nums.length];
		 
		for(int i = 0; i< nums.length; i++) {
			output[i] = setOutputExceptIth(i,nums);
		}			
		return output;
    }
	
	public static int setOutputExceptIth(int except,int [] nums) {
		int multiplication = 1 ;
		
		for(int i = 0; i< nums.length; i++) {
			if(i==except) {
				continue;
			}else {
				multiplication = multiplication * nums[i];
			}
		}		
		return multiplication;
	}

	public static void main(String [] ar) {
		int nums[] = new int[] {1,2,3,4};
		
		int []output = new ArraySolution().productExceptSelf(nums);
		
		for(int i: output) {
			System.out.println(i);
		}
	}
}
